Deploy notes:
- Open monitor-dashboard.html in a browser.
- For real-time production, connect backend endpoints for fixtures, lineups, injuries, odds, and alerts.
- Suggested providers: API-Football/API-Sports for football data, The Odds API for odds, Telegram Bot API for alerts.

Premium filter note: allow odds >= 1.55 for VIP mode.

Alert schedule: use Telegram Bot API /sendMessage from a daily Python job (cron or scheduler).
