# Cómo usar la página

1. Abre `index.html` en tu navegador.
2. La página se recarga sola cada 60 segundos.
3. Para que sea realmente live, conecta el backend de datos a las APIs de fútbol y cuotas.
4. Puedes subir toda la carpeta a un hosting estático o abrirla localmente.
5. Si quieres datos automáticos de verdad, el backend debe actualizar `monitor-dashboard.html` o un JSON conectado al panel.

## Fuentes recomendadas
- API-Football / API-Sports para fixtures, lineups, injuries y suspensions.
- The Odds API o un proveedor similar para cuotas.
- Telegram solo si luego quieres alertas, pero no es obligatorio para usar la web.
