# Pasos para dejarlo funcionando

1. Crea un bot con @BotFather.
2. Copia el token y ponlo en `TELEGRAM_TOKEN`.
3. Escribe a tu bot en Telegram y usa `@userinfobot` o una prueba para obtener `TELEGRAM_CHAT_ID`.
4. Consigue tus claves de API-Football y The Odds API.
5. Instala dependencias:
   `pip install python-telegram-bot requests`
6. Ejecuta:
   `python telegram_betting_bot.py`
7. En Telegram escribe `/start` y luego `/mejores` o `/hoy`.
8. Si quieres alertas automáticas diarias, deja el bot encendido en un VPS, servidor o PC 24/7.

Notas:
- El envío diario está programado a las 09:00 CEST.
- Para producción, sustituye `get_best_picks()` por llamadas reales a fixtures, lineups, injuries, suspensions, odds y noticias.
- Los picks VIP están filtrados para cuotas desde 1.55 en adelante, no cuotas ultra bajas.
