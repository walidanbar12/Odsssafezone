import os
import datetime as dt
import requests
from telegram import Update
from telegram.ext import Application, CommandHandler, ContextTypes

TELEGRAM_TOKEN = os.getenv("TELEGRAM_TOKEN", "")
TELEGRAM_CHAT_ID = os.getenv("TELEGRAM_CHAT_ID", "")
API_FOOTBALL_KEY = os.getenv("API_FOOTBALL_KEY", "")
ODDS_API_KEY = os.getenv("ODDS_API_KEY", "")

TIMEZONE_OFFSET = dt.timezone(dt.timedelta(hours=2))  # CEST
SEND_TIME = dt.time(hour=9, minute=0, tzinfo=TIMEZONE_OFFSET)
VIP_MIN_ODDS = 1.55
VIP_MIN_PROB = 0.68
VIP_MIN_EDGE = 0.03

SPORTS = ["soccer_epl", "soccer_spain_la_liga", "soccer_italy_serie_a", "soccer_uefa_champs_league"]

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("Bot activo. Usa /mejores para recibir los mejores partidos del día y /hoy para el resumen actual.")

async def mejores(update: Update, context: ContextTypes.DEFAULT_TYPE):
    picks = get_best_picks()
    await update.message.reply_text(format_message(picks, title="MEJORES PARTIDOS"))

async def hoy(update: Update, context: ContextTypes.DEFAULT_TYPE):
    picks = get_best_picks()
    await update.message.reply_text(format_message(picks, title="APUESTAS DEL DÍA"))

async def daily_job(context: ContextTypes.DEFAULT_TYPE):
    if not TELEGRAM_CHAT_ID:
        return
    picks = get_best_picks()
    await context.bot.send_message(chat_id=TELEGRAM_CHAT_ID, text=format_message(picks, title="APUESTAS DEL DÍA"))

def get_best_picks():
    # TODO: sustituir por consultas reales a API-Football + odds provider.
    # Estructura esperada: fixtures, lineups, injuries, suspensions, odds, news signals.
    sample = [
        {"match": "Inter vs Roma", "market": "1", "odds": 1.78, "prob": 0.72, "edge": 0.08, "stake": "1.0u", "reason": "Sanción clave + once fuerte + cuota aún útil"},
        {"match": "Fiorentina vs Atalanta", "market": "Over 1.5", "odds": 1.66, "prob": 0.73, "edge": 0.06, "stake": "0.75u", "reason": "Perfil ofensivo y bajas defensivas"},
        {"match": "Bayern vs PSG", "market": "BTTS", "odds": 1.70, "prob": 0.71, "edge": 0.05, "stake": "0.75u", "reason": "Contexto de gol y precio razonable"},
    ]
    return [p for p in sample if p["odds"] >= VIP_MIN_ODDS and p["prob"] >= VIP_MIN_PROB and p["edge"] >= VIP_MIN_EDGE]

def format_message(picks, title="APUESTAS"):
    if not picks:
        return f"{title}

Sin picks premium claros ahora mismo."
    lines = [title]
    for p in picks:
        lines += [
            f"
{p['match']}",
            f"Mercado: {p['market']} | Cuota: {p['odds']:.2f}",
            f"Prob: {int(p['prob']*100)}% | Edge: {int(p['edge']*100)}% | Stake: {p['stake']}",
            f"Motivo: {p['reason']}",
        ]
    return "
".join(lines)

def main():
    if not TELEGRAM_TOKEN:
        raise SystemExit("Falta TELEGRAM_TOKEN")
    app = Application.builder().token(TELEGRAM_TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("mejores", mejores))
    app.add_handler(CommandHandler("hoy", hoy))
    app.job_queue.run_daily(daily_job, time=SEND_TIME, name="daily_picks")
    app.run_polling()

if __name__ == "__main__":
    main()
